class Node:
      ## creating nodes
  
      def __init__(self, value):
        self.value = value
        self.prev = None
        self.next = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def __str__(self):

        values = []
        current = self.head
        while current is not None:
            values.append(str(current.value))
            current = current.next
        return "[" + ", ".join(values) + "]"

    def is_empty(self):
        return self.size == 0

    def get_size(self):
        return self.size

    def add_first(self, value):
        ## add first element
        new_node = Node(value)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node
        self.size += 1

    def add_last(self, value):
        #add value 
        new_node = Node(value)
        if self.is_empty():
            self.head = new_node
            self.tail = new_node
        else:
            new_node.prev = self.tail
            self.tail.next = new_node
            self.tail = new_node
        self.size += 1

    def remove_first(self):
        #remove the first value 
        if self.is_empty():
            raise IndexError("remove_first from empty list")
        value = self.head.value
        self.head = self.head.next
        if self.head is not None:
            self.head.prev = None
        else:
            # List is now empty
            self.tail = None
        self.size -= 1
        return value

    def remove_last(self):
        #removes last value
        if self.is_empty():
            raise IndexError("remove_last from empty list")
        value = self.tail.value
        self.tail = self.tail.prev
        if self.tail is not None:
            self.tail.next = None
        else:
            # List is now empty
            self.head = None
        self.size -= 1
        return value

    def first(self):
        #return first value 
        if self.is_empty():
            return None
        return self.head.value

    def last(self):
        #return last vlaue
        if self.is_empty():
            return None
        return self.tail.value

    def search(self, value):
        #index of value
        current = self.head
        index = 0
        while current is not None:
            if current.value == value:
                return index
            current = current.next
            index += 1
        return -1

    def get(self, index):
        #get value at index
        if index < 0 or index >= self.size:
            raise IndexError("Index out of range")

        # Choose from head or tail 
        if index < self.size // 2:
            current = self.head
            for _ in range(index):
                current = current.next
        else:
            current = self.tail
            for _ in range(self.size - 1, index, -1):
                current = current.prev
        return current.value
