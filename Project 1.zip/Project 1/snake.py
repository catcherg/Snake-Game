import random
import dudraw  
from doublylinkedlists import DoublyLinkedList  

GRID_SIZE = 20

class SnakeGame:
    def __init__(self):
        dudraw.set_canvas_size(500, 500)  
        dudraw.set_x_scale(0, GRID_SIZE)
        dudraw.set_y_scale(0, GRID_SIZE)

        # Initial snake size and position
        self.snake = DoublyLinkedList()
        start_x = GRID_SIZE // 2
        start_y = GRID_SIZE // 2

        # Put 3 segments for the initial snake
        self.snake.add_first((start_x, start_y))
        self.snake.add_last((start_x-1, start_y))
        self.snake.add_last((start_x-2, start_y))

        # Movement direction
        self.dx = 1
        self.dy = 0

        # Generate initial food
        self.food_x, self.food_y = self.random_food_position()

        # A timer to control movement speed
        self.timer = 0
        self.move_limit = 20  # bigger number = slower snake

        self.game_over = False

    def random_food_position(self):
        #gets position for random food
        while True:
            fx = random.randint(0, GRID_SIZE-1)
            fy = random.randint(0, GRID_SIZE-1)

            # Check that (x, y) is not in the snake
            collision = False
            for i in range(self.snake.get_size()):
                if self.snake.get(i) == (fx, fy):
                    collision = True
                    break

            if not collision:
                return fx, fy

    def run(self):
        while not self.game_over:
            self.process_input()
            self.timer += 1

            if self.timer == self.move_limit:
                self.timer = 0
                self.update()
            
            self.draw()
            dudraw.show(40)  

        #game over 
        print("Game Over!")
        dudraw.clear(dudraw.WHITE)
        dudraw.text(GRID_SIZE / 2, GRID_SIZE / 2, "GAME OVER!")
        dudraw.show()

    def process_input(self):
        #check which key is input and move in that direction
        if dudraw.has_next_key_typed():
            key = dudraw.next_key_typed()
            if key == 'w' and self.dy == 0:  # up
                self.dx, self.dy = 0, 1
            elif key == 's' and self.dy == 0:  # down
                self.dx, self.dy = 0, -1
            elif key == 'a' and self.dx == 0:  # left
                self.dx, self.dy = -1, 0
            elif key == 'd' and self.dx == 0:  # right
                self.dx, self.dy = 1, 0

    def update(self):
        #move snake
        old_head = self.snake.first() 
        new_head_x = old_head[0] + self.dx
        new_head_y = old_head[1] + self.dy

        # Check wall collision
        if not (0 <= new_head_x < GRID_SIZE and 0 <= new_head_y < GRID_SIZE):
            self.game_over = True
            return

        # Check self collision
        for i in range(self.snake.get_size()):
            if self.snake.get(i) == (new_head_x, new_head_y):
                self.game_over = True
                return

        # Add new head
        self.snake.add_first((new_head_x, new_head_y))

        # Check if food has been eaten 
        if new_head_x == self.food_x and new_head_y == self.food_y:
            # Generate new food position
            self.food_x, self.food_y = self.random_food_position()
        else:
            # Remove tail
            self.snake.remove_last()

    def draw(self):
        #draw the snake and the food
        dudraw.clear(dudraw.WHITE)

        # Draw food
        dudraw.set_pen_color(dudraw.RED)
        dudraw.filled_circle(self.food_x + 0.5, self.food_y + 0.5, 0.4)

        # Draw snake
        dudraw.set_pen_color(dudraw.GREEN)
        for i in range(self.snake.get_size()):
            x, y = self.snake.get(i)
            dudraw.filled_square(x + 0.5, y + 0.5, 0.45)

        dudraw.set_pen_color(dudraw.LIGHT_GRAY)
        for i in range(GRID_SIZE+1):
            dudraw.line(i, 0, i, GRID_SIZE)
            dudraw.line(0, i, GRID_SIZE, i)

def main():
    game = SnakeGame()
    game.run()

if __name__ == "__main__":
    main()
