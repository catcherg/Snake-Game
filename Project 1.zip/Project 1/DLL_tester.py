from doublylinkedlists import DoublyLinkedList
def dll_tester():
    test_list = DoublyLinkedList()

    # Test 1: list should start empty
    assert test_list.get_size() == 0, "List should be empty to start!"

    # Testing add_first
    test_list.add_first(1)
    assert test_list.first() == 1, "add_first error 1"
    assert test_list.last() == 1, "add_first error 2"
    assert test_list.get_size() == 1, "add_first error 3"

    test_list.add_first(2)
    assert test_list.first() == 2, "add_first error 4"
    assert test_list.last() == 1, "add_first error 5"
    assert test_list.get_size() == 2, "add_first error 6"

    # Testing add_last
    test_list.add_last(3)
    assert test_list.first() == 2, "add_last error 1"
    assert test_list.last() == 3,  "add_last error 2"
    assert test_list.get_size() == 3, "add_last error 3"

    # Test remove_first
    val = test_list.remove_first()
    assert val == 2, "remove_first error 1"
    assert test_list.first() == 1, "remove_first error 2"
    assert test_list.last() == 3, "remove_first error 3"
    assert test_list.get_size() == 2, "remove_first error 4"

    # Test remove_last
    val = test_list.remove_last()
    assert val == 3, "remove_last error 1"
    assert test_list.first() == 1, "remove_last error 2"
    assert test_list.last() == 1, "remove_last error 3"
    assert test_list.get_size() == 1, "remove_last error 4"

    # Remove the remaining element
    test_list.remove_first()
    assert test_list.get_size() == 0, "List should be empty now"

    # Add 10 elements (1..10)
    for i in range(10):
        test_list.add_last(i+1)

    # Test get method
    assert test_list.get(0) == 1,  "get(0) should return 1"
    assert test_list.get(5) == 6,  "get(5) should return 6"
    assert test_list.get(9) == 10, "get(9) should return 10"

    # Test search
    assert test_list.search(1) == 0,  "search(1) should return index 0"
    assert test_list.search(10) == 9, "search(10) should return index 9"
    assert test_list.search(99) == -1, "search(99) should return -1"

    print("All tests passed!")

if __name__ == "__main__":
    dll_tester()
